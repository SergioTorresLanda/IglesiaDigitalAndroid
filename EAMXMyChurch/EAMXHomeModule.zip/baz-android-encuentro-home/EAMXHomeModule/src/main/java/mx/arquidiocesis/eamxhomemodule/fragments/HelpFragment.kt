package mx.arquidiocesis.eamxhomemodule.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import mx.arquidiocesis.eamxhomemodule.R

class HelpFragment : Fragment(R.layout.fragment_help) {


    companion object {
        @JvmStatic
        fun newInstance() = HelpFragment
    }
}