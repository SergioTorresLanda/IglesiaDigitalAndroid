package mx.arquidiocesis.eamxhomemodule

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import mx.arquidiocesis.eamxhomemodule.databinding.EamxMainActivityBinding

class EAMXMainActivity : AppCompatActivity() {

    lateinit var mBinding: EamxMainActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = EamxMainActivityBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        mBinding.apply {
            val navController = findNavController(R.id.contentFragmentView)

            bottomNavigation.setupWithNavController(navController)

        }
    }
}