package mx.arquidiocesis.eamxhomemodule.model

data class MyModel(val id: String, val img: String, val text: String)