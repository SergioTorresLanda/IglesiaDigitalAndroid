package mx.arquidiocesis.misiglesias.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import mx.arquidiocesis.misiglesias.repository.Repository
import java.lang.IllegalArgumentException

class DetalleIglesiaViewModelFactory(private val repository: Repository) : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DetalleIglesiaViewModel::class.java)) {
            return DetalleIglesiaViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown View Model class")
    }
}