package mx.arquidiocesis.misiglesias.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ActivitiesModel(var id: Int, var days: String,var hours:String) : Parcelable//ACTIVIDADES