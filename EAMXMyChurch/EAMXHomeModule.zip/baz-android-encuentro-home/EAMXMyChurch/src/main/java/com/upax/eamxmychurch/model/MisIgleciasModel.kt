package mx.arquidiocesis.misiglesias.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MisIgleciasModel(//Primera pantalla
    var assigned: AssignedModel,
    var churches: List<churchesModel>

) : Parcelable