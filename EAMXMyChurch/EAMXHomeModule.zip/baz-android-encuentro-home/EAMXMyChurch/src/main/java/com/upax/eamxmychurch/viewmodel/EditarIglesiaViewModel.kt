package mx.arquidiocesis.misiglesias.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.android.synthetic.main.fragment_edit_church.*
import mx.arquidiocesis.misiglesias.model.EditarIglesiasModel
import mx.arquidiocesis.misiglesias.model.MassesModel
import mx.arquidiocesis.misiglesias.model.ServicesModel
import mx.arquidiocesis.misiglesias.repository.Repository

class EditarIglesiaViewModel(private val repository: Repository) : ViewModel() {

    val response = repository.iglesiasPutResponse
    var errorResponse = repository.errorResponse
    var validateForm = MutableLiveData<HashMap<String, String>>()
    val catalogoMassesResponse = repository.catalogoMassesResponse
    val catalogoServiciosResponse = repository.catalogoServiciosResponse
    val responseDetalle = repository.detalleResponse

    fun getCatalogServicios(){
        repository.getCatalogServicios()
    }
    fun getCatalogMisas(){
        repository.getCatalogMisas()
    }
    fun putIglesias(id: Int, editarIglesiasModel: EditarIglesiasModel) {
        val validateForm: HashMap<String, String> = HashMap()

        if (editarIglesiasModel.description.isEmpty()) {
            validateForm.put("description", "Error description")
        }

        if (editarIglesiasModel.email.isEmpty()) {
            validateForm.put("email", "Error email")
        }

        // TODO Verificar el formato que tendra este campos si una URL o como
        if (editarIglesiasModel.image.isEmpty()) {
            validateForm.put("image", "Error image")
        }

        if (editarIglesiasModel.services.isEmpty()) {
            validateForm.put("services", "Error services")
        }

        if (editarIglesiasModel.masses.isEmpty()) {
            validateForm.put("masses", "Error masses")
        }

        editarIglesiasModel.attention.forEach {
            if (it.days.isEmpty() || it.hours.isEmpty()) {
                validateForm.put("masses", "Error masses")
            }
        }


        if (editarIglesiasModel.phone.isEmpty()) {
            validateForm.put("phone", "Error phone")
        }

       if (editarIglesiasModel.parson == 0) {
            validateForm.put("parson", "Error parson")
        }

        if (editarIglesiasModel.stream.url.isEmpty() ){//|| editarIglesiasModel.stream.hours.isEmpty()) {
            validateForm.put("stream", "Error stream")
        }

        if (editarIglesiasModel.priest.isEmpty()) {
            validateForm.put("priest", "Error priest")
        }

        if (editarIglesiasModel.bankAccount.isEmpty()) {
            validateForm.put("bankAccount", "Error bankAccount")
        }

     /*   if (editarIglesiasModel.confessions.isEmpty()) {
            validateForm.put("confessions", "Error confessions")
        }

        if (editarIglesiasModel.activities.isEmpty()) {
            validateForm.put("activities", "Error activities")
        }
*/
        if (validateForm.size > 0) {
            this.validateForm.value = validateForm
        } else {
            repository.putIglesias(id, editarIglesiasModel)
        }
    }

    fun obtenerDetalle(id: Int) {
        repository.obtenerDetalle(id)
    }
}