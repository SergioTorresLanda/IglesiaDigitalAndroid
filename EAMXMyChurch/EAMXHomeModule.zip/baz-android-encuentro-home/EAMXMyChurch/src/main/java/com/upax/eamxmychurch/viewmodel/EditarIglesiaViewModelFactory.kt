package mx.arquidiocesis.misiglesias.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import mx.arquidiocesis.misiglesias.repository.Repository
import java.lang.IllegalArgumentException

class EditarIglesiaViewModelFactory(private val repository: Repository) : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EditarIglesiaViewModel::class.java)) {
            return EditarIglesiaViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown View Model class")
    }
}