package mx.arquidiocesis.misiglesias.config

object WebConfi {
    const val HOST = "https://encuentro-cdmx.getsandbox.com:443/"
    const val IGLESIASLISTADO = "priest/{priestId}/churches"
    const val IGLESIASDETALLE = "churches/{idChurch}"
    const val CATALOGOMISAS = "catalogs/masses"
    const val CATALOGOSEVICIOS = "catalogs/services"
}