package mx.arquidiocesis.misiglesias.adapters

import android.app.AlertDialog
import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.upax.eamxmychurch.databinding.ItemServiceBinding
import kotlinx.android.synthetic.main.fragment_edit_church.*
import mx.arquidiocesis.misiglesias.model.ServicesModel
import mx.arquidiocesis.misiglesias.utils.PublicFunctions


class ServiceAdapter(
    val context: Context,
    var services: MutableList<ServicesModel>,
    var recyclerView: RecyclerView,
    val listener: (ServicesModel) -> Unit
) :
    RecyclerView.Adapter<ServiceAdapter.ServicesViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ServicesViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemServiceBinding.inflate(inflater, parent, false)
        return ServicesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ServicesViewHolder, position: Int) =
        holder.bind(context, listener, services[position], this)

    override fun getItemCount(): Int = services.size
    fun updateReceiptsList(item: ServicesModel) {
        services.add(item)
        recyclerView.post(Runnable { notifyDataSetChanged() })
    }
    fun updateReceiptsList(item: MutableList<ServicesModel>) {
        services=item
        recyclerView.post(Runnable { notifyDataSetChanged() })
    }
    fun deleteReceiptsList(item: ServicesModel) {
        services.remove(item)
        recyclerView.post(Runnable { notifyDataSetChanged() })
    }

    class ServicesViewHolder(val binding: ItemServiceBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(
            context: Context, listener: (ServicesModel) -> Unit, service: ServicesModel,
            adapter: ServiceAdapter
        ) {
            binding.tvServicio.text = service.name
            if (service.day !== null) {
                binding.tvDia.text = service.day
            }
            if (service.hours!== null) {
                binding.tvHorario.text = service.hours
            }

            Glide.with(context)
                .load(Uri.parse(service.icon)).apply(RequestOptions().override(40, 50))
                .into(binding.ivIcon)

            binding.imClose.setOnClickListener {
                adapter.deleteReceiptsList(service)
            }

            binding.ivEditDays.setOnClickListener {
                val days =
                    mutableListOf("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo")
                PublicFunctions().selectDayRange(context, binding.tvDia,days,"")
            }

            binding.ivEditHours.setOnClickListener {
                PublicFunctions().selectFirstHour(context, binding.tvHorario,"")
            }

            binding.root.setOnClickListener {
                listener(service)
            }
        }


    }
}