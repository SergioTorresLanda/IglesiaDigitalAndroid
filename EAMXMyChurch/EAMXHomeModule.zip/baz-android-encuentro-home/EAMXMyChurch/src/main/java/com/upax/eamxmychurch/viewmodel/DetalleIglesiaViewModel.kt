package mx.arquidiocesis.misiglesias.viewmodel

import androidx.lifecycle.ViewModel
import mx.arquidiocesis.misiglesias.repository.Repository

class DetalleIglesiaViewModel(private val repository: Repository) : ViewModel() {

    val response = repository.detalleResponse
    var errorResponse = repository.errorResponse

    fun obtenerDetalle(id: Int) {
        repository.obtenerDetalle(id)
    }


}