package mx.arquidiocesis.misiglesias.utils

import android.app.AlertDialog
import android.content.Context
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat

class PublicFunctions {

    fun selectFirstHour(context: Context, tv: TextView, horarios: String) {

        val picker =
            MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_12H)
                .setHour(12)
                .setMinute(10)
                .build()

        picker.show((context as AppCompatActivity).supportFragmentManager, "tag");


        picker.addOnPositiveButtonClickListener {
            nuevoHorario(context, tv, horarios + " ${picker.hour}:${input(picker.minute)}")

        }
        picker.addOnDismissListener {

            tv.text = horarios
        }

    }


    fun selectDayRange(context: Context, tvDia: TextView, days: MutableList<String>, dias: String) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Selecciona los dias")


        var selecion: Int = -1
        builder.setSingleChoiceItems(days.toTypedArray(), selecion) { dialog, which ->
            selecion = which
        }

        builder.setPositiveButton("Aceptar") { dialog, which ->

            val dia = "${dias} ${days[selecion]}"
            days.remove(days[selecion])
            if (days.size != 0) {
                nuevoDia(context, tvDia, dia, days)
            }else{
                tvDia.text = dias
            }

            //selectFirstHour(context, tvDia, "${tvDia.text} ${days[selecion]}")
        }
        builder.setNegativeButton("Cancelar") { dialog, which ->
            tvDia.text = dias
        }

        val dialog = builder.create()
        dialog.show()
    }

    fun nuevoDia(context: Context, tv: TextView, dias: String, days: MutableList<String>) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Desea agregar otro dia")

        builder.setPositiveButton("Aceptar") { dialog, which ->

            selectDayRange(context, tv, days, dias)
        }
        builder.setNegativeButton("Cancelar") { dialog, which ->
            tv.text = dias

        }
        val dialog = builder.create()
        dialog.show()
    }

    fun nuevoHorario(context: Context, tv: TextView, horarios: String) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Desea agregar otro horario")

        builder.setPositiveButton("Aceptar") { dialog, which ->

            selectFirstHour(context, tv, horarios + " hrs")
        }
        builder.setNegativeButton("Cancelar") { dialog, which ->
            tv.text = horarios + " hrs"

        }
        val dialog = builder.create()
        dialog.show()
    }

    fun input(input: Int): String {
        return if (input >= 10) {
            input.toString()
        } else {
            "0$input"
        }
    }
}
