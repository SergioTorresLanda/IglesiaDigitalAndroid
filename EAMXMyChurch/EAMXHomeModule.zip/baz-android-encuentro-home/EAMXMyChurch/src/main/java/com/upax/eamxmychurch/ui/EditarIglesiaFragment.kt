package mx.arquidiocesis.misiglesias.ui

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.app.ActivityCompat.recreate
import androidx.core.content.ContextCompat.getSystemService
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.observe
import androidx.recyclerview.widget.LinearLayoutManager
import com.arquidiocesis.misiglesias.R
import com.bumptech.glide.Glide
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import kotlinx.android.synthetic.main.fragment_detail_church.*
import kotlinx.android.synthetic.main.fragment_edit_church.*
import kotlinx.android.synthetic.main.fragment_edit_church.ivChurch
import mx.arquidiocesis.misiglesias.adapters.MassAdapter
import mx.arquidiocesis.misiglesias.adapters.PriestAdapter
import mx.arquidiocesis.misiglesias.adapters.ServiceAdapter
import mx.arquidiocesis.misiglesias.customviews.LoadingFragment
import mx.arquidiocesis.misiglesias.model.*
import mx.arquidiocesis.misiglesias.repository.Repository
import mx.arquidiocesis.misiglesias.utils.CameraPermissionHelper
import mx.arquidiocesis.misiglesias.viewmodel.EditarIglesiaViewModel
import mx.arquidiocesis.misiglesias.viewmodel.EditarIglesiaViewModelFactory

class EditarIglesiaFragment : Fragment() {
    private val factory by lazy { EditarIglesiaViewModelFactory(Repository()) }
    private val editarIglesiaViewModel: EditarIglesiaViewModel by viewModels { factory }
    private var serviciosList: MutableList<ServicesModel> = mutableListOf()
    private var massesList: MutableList<MassesModel> = mutableListOf()
    private var priestList: MutableList<ParsonModel> = mutableListOf()
    lateinit var serviceAdapter: ServiceAdapter
    lateinit var massAdapter: MassAdapter
    val HORARY = "HORARY"
    val ATENTTION = "ATENTTION"
    private val loadingFragment by lazy { LoadingFragment() }

    val PICKIMAGE = 100
    val TAKEIMAGE = 200

    private var imageUri: Uri? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_edit_church, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val idIglesia = requireArguments().getInt("idIglesia")
        initObservers()
        initListener()
        showLoader()
        serviceAdapter = ServiceAdapter(requireContext(), serviciosList, rvServicios) {

        }
        massAdapter = MassAdapter(requireContext(), massesList, rvMisas) {

        }
        editarIglesiaViewModel.obtenerDetalle(idIglesia)
    }

    fun initObservers() {
        editarIglesiaViewModel.response.observe(viewLifecycleOwner) {
            Toast.makeText(requireContext(), it.status, Toast.LENGTH_LONG).show()
            requireActivity().onBackPressed()
        }
        editarIglesiaViewModel.catalogoMassesResponse.observe(viewLifecycleOwner) {
            it.let {
                val listMasses: ArrayList<String> = ArrayList()
                listMasses.add("")
                for (masses in it) {
                    listMasses.add(masses.name)
                }

                val adapterSpinner = ArrayAdapter(
                    requireContext(),
                    R.layout.custom_spinner_item, listMasses
                )

                spMisas.adapter = adapterSpinner

                rvMisas.apply {
                    layoutManager =
                        LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
                    adapter = massAdapter
                }
                spMisas.onItemSelectedListener = object :
                    AdapterView.OnItemSelectedListener {

                    override fun onItemSelected(
                        parent: AdapterView<*>,
                        view: View?, position: Int, id: Long
                    ) {
                        if (position != 0) {
                            var item = it[position - 1]
                            addMasses(item)
                        }

                    }

                    override fun onNothingSelected(parent: AdapterView<*>) {
                        // write code to perform some action
                    }
                }
            }
            editarIglesiaViewModel.getCatalogServicios()
        }

        editarIglesiaViewModel.catalogoServiciosResponse.observe(viewLifecycleOwner) {
            it.let {
                val list: ArrayList<String> = ArrayList()
                list.add("")
                for (masses in it) {
                    list.add(masses.name)
                }

                val adapterSpinner = ArrayAdapter(
                    requireContext(),
                    R.layout.custom_spinner_item, list
                )

                spServicios.adapter = adapterSpinner


                rvServicios.apply {
                    layoutManager =
                        LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
                    adapter = serviceAdapter
                }
                spServicios.onItemSelectedListener = object :
                    AdapterView.OnItemSelectedListener {

                    override fun onItemSelected(
                        parent: AdapterView<*>,
                        view: View?, position: Int, id: Long
                    ) {
                        if (position != 0) {
                            if(position==2){
                                etOtroServicio.visibility=View.VISIBLE
                            }
                            var services = it[position - 1]
                            addServices(services)
                        }

                    }

                    override fun onNothingSelected(parent: AdapterView<*>) {
                        // write code to perform some action
                    }
                }
                hideLoader()
            }
        }


        editarIglesiaViewModel.validateForm.observe(viewLifecycleOwner) {
            if (it.containsKey("description")) {
                etDescripcionIglesia.error = "Campo Obligatorio"
            }
           if (it.containsKey("parson")) {
                nombreSacerdote.error = "Campo Obligatorio"
            }
            if (it.containsKey("email")) {
                etEmailSacerdote.error = "Campo Obligatorio"
            }

            if (it.containsKey("services")) {
                Toast.makeText(
                    context,
                    "Selecciona un servicio",
                    Toast.LENGTH_LONG
                ).show()
            }

            if (it.containsKey("masses")) {
                Toast.makeText(
                    context,
                    "Selecciona una misa",
                    Toast.LENGTH_LONG
                ).show()
            }

            if (it.containsKey("image")) {
                Toast.makeText(
                    context,
                    "Cargue un imagen",
                    Toast.LENGTH_LONG
                ).show()
            }

            if (it.containsKey("phone")) {
                etTelefono.error = "Campo Obligatorio"
            }

            /*if (it.containsKey("priest")) {
                etNombreSacerdote.error = "Campo Obligatorio"
            }*/

            if (it.containsKey("stream")) {
                etUrlCanal.error = "Campo Obligatorio"
            }

            if (it.containsKey("attention")) {
                Toast.makeText(
                    context,
                    "Selecciona un horario",
                    Toast.LENGTH_LONG
                ).show()
            }

            if (it.containsKey("bankAccount")) {
                Toast.makeText(
                    context,
                    "agregue un numero de cuenta",
                    Toast.LENGTH_LONG
                ).show()
            }

            if (it.containsKey("activities")) {
                Toast.makeText(
                    context,
                    "Seleccione una actividad",
                    Toast.LENGTH_LONG
                ).show()
            }

            if (it.containsKey("parson")) {
                Toast.makeText(
                    context,
                    "Seleccione una actividad",
                    Toast.LENGTH_LONG
                ).show()
            }

            if (it.containsKey("confessions")) {
                Toast.makeText(
                    context,
                    "Seleccione una actividad",
                    Toast.LENGTH_LONG
                ).show()
            }

        }

        editarIglesiaViewModel.responseDetalle.observe(viewLifecycleOwner) {

            Glide.with(requireContext())
                .load(Uri.parse(it.image))
                .into(ivChurch)

            etDia.setText(it.horary.get(0).days)
            etHora.setText(it.horary.get(0).hours)
            etDiaOficina.setText(it.attention.get(0).days)
            etHoraOficina.setText(it.attention.get(0).hours)
            //image = "https://pbs.twimg.com/media/D7WSdcyU0AA1LMh.jpg",
            etDescripcionIglesia.setText(it.description)
            etSacerdote.setText(it.parson.name)
            // parson = 1
            etEmailSacerdote.setText(it.email)
            etTelefono.setText(it.phone)
            etUrlCanal.setText(it.stream.url)
            var priestAdapter = PriestAdapter(it.priest as MutableList<ParsonModel>, rvSacerdote) {}

            rvSacerdote.apply {
                layoutManager =
                    LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
                adapter = priestAdapter


            }
            etNumeroCuenta.setText(it.bankAccount)
            rvServicios.apply {
                addMassesList(it.masses as MutableList<MassesModel>)
                layoutManager =
                    LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
                adapter = massAdapter
            }

            rvServicios.apply {
                addServicesList(it.services as MutableList<ServicesModel>)
                layoutManager =
                    LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
                adapter = serviceAdapter
            }

            ivAgregar.setOnClickListener {
                if (!etNombreSacerdote.text.isEmpty()) {
                    if (!etNumeroCuenta.text.isEmpty()) {
                        priestAdapter.updateReceiptsList(
                            ParsonModel(
                                1,
                                "",
                                etNombreSacerdote.text.toString(),
                                "",
                                ""
                            )
                        )

                    } else {
                        etNumeroCuenta.error = "Campo Obligatorio"
                    }

                } else {
                    etNombreSacerdote.error = "Campo Obligatorio"
                }
            }
            editarIglesiaViewModel.getCatalogMisas()
        }
    }

    private fun initListener() {
        btnSave.setOnClickListener {

            var attention = AttentionModel(
                etDiaOficina.text.toString(), etHoraOficina.text.toString()
            )

            var streamModel = StreamModel(
                etUrlCanal.text.toString(), ""
            )

            var putIglesias = EditarIglesiasModel(
                image = "https://pbs.twimg.com/media/D7WSdcyU0AA1LMh.jpg",
                description = etDescripcionIglesia.text.toString(),
                parson = 1,
                horary = listOf(HoraryModel(etDia.text.toString(), etHora.text.toString())),
                attention = listOf(attention),
                email = etEmailSacerdote.text.toString(),
                phone = etTelefono.text.toString(),
                stream = streamModel,// StreamModel
                priest = listOf(PriestModel(1)),
                bankAccount = etNumeroCuenta.text.toString(),

                services = listOf(
                    ServicesModel(
                        spServicios.id,
                        "",
                        "",
                        "",
                        ""
                    )
                ), // List<ServicesModel>
                masses = listOf(MassesModel(id, "", "", "", "")), //List<MassesModel>

                confessions = listOf(), // List<ConfessionsModel>
                activities = listOf(), // List<ActivitiesModel>
            )
            editarIglesiaViewModel.putIglesias(1, putIglesias)
        }

        ivCalendario.setOnClickListener {
            selectDayRange(HORARY)
        }

        ivHora.setOnClickListener {
            selectFirstHour(HORARY)
        }

        ivCalendarioOficina.setOnClickListener {
            selectDayRange(ATENTTION)
        }

        ivHoraOficina.setOnClickListener {
            selectFirstHour(ATENTTION)
        }

        swTransmisiones.setOnCheckedChangeListener { compoundButton, b ->
            if (b) {
                etUrlCanal.visibility = View.VISIBLE
            } else {
                etUrlCanal.visibility = View.GONE
            }
        }

        ivCamera.setOnClickListener {

            if (!CameraPermissionHelper.hasCameraPermission(this.requireActivity())) {
                CameraPermissionHelper.requestCameraPermission(this.requireActivity())
                return@setOnClickListener
            }

            activity?.let {
                val builder = AlertDialog.Builder(it)
                builder.apply {
                    setTitle("App encuentro")
                    setMessage("Selecciona una método para obtener la imagén")
                    setPositiveButton("Tomar foto", { dialog, id ->
                        capturePhoto()
                    })

                    setNegativeButton("Seleccionar foto", { dialog, id ->
                        selectPhoto()
                    })
                }
                builder.create()
                builder.show()
            }

        }
    }

    fun selectPhoto() {
        val gallery = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
        startActivityForResult(gallery, PICKIMAGE)
    }

    fun capturePhoto() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(cameraIntent, TAKEIMAGE)
    }

    fun selectDayRange(origin: String) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Selecciona los dias")

        val days = arrayOf("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo")
        val checkedItems = booleanArrayOf(false, false, false, false, false, false, false)
        builder.setMultiChoiceItems(days, checkedItems) { dialog, which, isChecked ->
            checkedItems[which] = isChecked
        }

        builder.setPositiveButton("Aceptar") { dialog, which ->
            if (origin.equals("HORARY")) {
                etDia.setText("")
            } else {
                etDiaOficina.setText("")
            }

            checkedItems.forEachIndexed { index, value ->
                if (value) {
                    if (origin.equals("HORARY")) {
                        etDia.setText("${etDia.text} ${days[index]}")
                    } else {
                        etDiaOficina.setText("${etDiaOficina.text} ${days[index]}")
                    }
                }
            }
        }
        builder.setNegativeButton("Cancelar", null)
        val dialog = builder.create()
        dialog.show()
    }

    fun addMasses(massesModel: MassesModel) {
        if (!massesList.contains(massesModel)) {
            massAdapter.updateReceiptsList(massesModel)
        }
    }
    fun addServices(servicesModel: ServicesModel) {
        if (!serviciosList.contains(servicesModel)) {
            serviceAdapter.updateReceiptsList(servicesModel)
        }
    }

    fun addMassesList(list: MutableList<MassesModel>) {
        massAdapter.updateReceiptsList(list)
    }

    fun addServicesList(list: MutableList<ServicesModel>) {
        serviceAdapter.updateReceiptsList(list)
    }



    fun selectRange(origin: String) {
        val builder = MaterialDatePicker.Builder.dateRangePicker()
    }

    fun selectFirstHour(origin: String) {
        val picker =
            MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_12H)
                .setHour(12)
                .setMinute(10)
                .build()

        fragmentManager?.let { picker.show(it, "tag") };

        picker.addOnPositiveButtonClickListener {
            if (origin.equals("HORARY")) {
                etHora.setText("${picker.hour}:${input(picker.minute)}")
            } else {
                etHoraOficina.setText("${picker.hour}:${input(picker.minute)}")
            }

            selectSecondtHour(origin)
        }
    }

    fun selectSecondtHour(origin: String) {
        val picker =
            MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_12H)
                .setHour(12)
                .setMinute(10)
                .build()

        fragmentManager?.let { picker.show(it, "tag") };

        picker.addOnPositiveButtonClickListener {
            if (origin.equals("HORARY")) {
                etHora.setText("${etHora.text} - ${picker.hour}:${input(picker.minute)}")
            } else {
                etHoraOficina.setText("${etHoraOficina.text} - ${picker.hour}:${input(picker.minute)}")
            }
        }
    }

    fun input(input: Int): String {
        return if (input >= 10) {
            input.toString()
        } else {
            "0$input"
        }
    }

    private fun showLoader() {
        if (!loadingFragment.isAdded) {
            loadingFragment.show(childFragmentManager, "lOADER")
        }
    }

    private fun hideLoader() {
        if (loadingFragment.isAdded) {
            loadingFragment.dismissAllowingStateLoss()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (!CameraPermissionHelper.hasCameraPermission(this.requireActivity())) {
            Toast.makeText(
                context,
                "Los permisos de la camara son necesarios",
                Toast.LENGTH_LONG
            ).show()
            if (!CameraPermissionHelper.shouldShowRequestPermissionRationale(this.requireActivity())) {
                CameraPermissionHelper.launchPermissionSettings(this.requireActivity())
            }
            activity?.finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == TAKEIMAGE && data != null) {
                ivChurch.setImageBitmap(data.extras?.get("data") as Bitmap)
            } else if (requestCode == PICKIMAGE) {
                ivChurch.setImageURI(data?.data)
            }
        }
    }
}