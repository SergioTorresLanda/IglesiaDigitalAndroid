package mx.arquidiocesis.misiglesias.retrofit


import mx.arquidiocesis.misiglesias.config.WebConfi
import mx.arquidiocesis.misiglesias.model.*
import org.json.JSONObject
import retrofit2.Call
import retrofit2.http.*

interface ApiInterface {
    @GET(WebConfi.IGLESIASLISTADO)
    fun getListadoIglesias(@Path("priestId")  id: Int): Call<MisIgleciasModel>

    @GET(WebConfi.IGLESIASDETALLE)
    fun getDetalleIglesias(@Path("idChurch") id: Int): Call<DetalleIglesiasModel>

    @Headers("Content-Type: application/json")
    @PATCH(WebConfi.IGLESIASDETALLE)
    fun addIglesiasRegister(@Path("idChurch") id: Int,@Body json: JSONObject): Call<RespuestaModel>

    @GET(WebConfi.CATALOGOMISAS)
    fun getCatalogMisas(): Call<List<MassesModel>>

    @GET(WebConfi.CATALOGOSEVICIOS)
    fun getCatalogServicios(): Call<List<ServicesModel>>
}