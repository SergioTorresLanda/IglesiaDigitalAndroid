package mx.arquidiocesis.misiglesias.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class EditarIglesiasModel(
    var image: String,
    var description: String,
    var parson: Int,
    var horary:List<HoraryModel>,
    var attention: List<AttentionModel>,
    var email: String,
    var phone: String,
    var stream: StreamModel,
    var priest: List<PriestModel>,
    var bankAccount: String,
    var services: List<ServicesModel>,
    var masses: List<MassesModel>,
    var confessions: List<ConfessionsModel>,
    var activities: List<ActivitiesEditModel>,

) : Parcelable
