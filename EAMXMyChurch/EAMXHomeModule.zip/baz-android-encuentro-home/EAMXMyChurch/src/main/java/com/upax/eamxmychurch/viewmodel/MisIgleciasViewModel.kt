package mx.arquidiocesis.misiglesias.viewmodel

import androidx.lifecycle.ViewModel
import mx.arquidiocesis.misiglesias.repository.Repository

class MisIgleciasViewModel(private val repository: Repository) : ViewModel() {

    val response = repository.iglesiasResponse
    var errorResponse = repository.errorResponse

    fun oracionesList(id: Int) {
        repository.iglesiasList(id)
    }


}