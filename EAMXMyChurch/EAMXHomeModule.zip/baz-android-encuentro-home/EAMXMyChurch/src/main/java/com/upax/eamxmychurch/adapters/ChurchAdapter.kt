package mx.arquidiocesis.misiglesias.adapters

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.upax.eamxmychurch.databinding.ItemChurchBinding
import mx.arquidiocesis.misiglesias.model.churchesModel

class ChurchAdapter(
    val context: Context,
    val churches: List<churchesModel>,
    val listener: (churchesModel) -> Unit

) :
    RecyclerView.Adapter<ChurchAdapter.ChurchViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChurchViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemChurchBinding.inflate(inflater, parent, false)
        return ChurchViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChurchViewHolder, position: Int) =
        holder.bind(context, listener, churches[position])

    override fun getItemCount(): Int = churches.size

    class ChurchViewHolder(val binding: ItemChurchBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(
            context: Context,
            listener: (churchesModel) -> Unit,
            church: churchesModel
        ) {
            binding.tvChurch.text = church.description

          Glide.with(context)
                .load(Uri.parse(church.image))
                .into(binding.ivChurch)

            binding.root.setOnClickListener {
                listener(church)
            }
        }
    }
}