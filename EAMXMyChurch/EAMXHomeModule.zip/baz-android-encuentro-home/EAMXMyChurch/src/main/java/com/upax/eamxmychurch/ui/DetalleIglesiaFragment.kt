package mx.arquidiocesis.misiglesias.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.observe
import androidx.recyclerview.widget.LinearLayoutManager
import com.arquidiocesis.misiglesias.R
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.fragment_detail_church.*
import mx.arquidiocesis.misiglesias.adapters.MassAdapter
import mx.arquidiocesis.misiglesias.adapters.ServiceAdapter
import mx.arquidiocesis.misiglesias.customviews.LoadingFragment
import mx.arquidiocesis.misiglesias.model.CoordinatesModel
import mx.arquidiocesis.misiglesias.model.MassesModel
import mx.arquidiocesis.misiglesias.model.ServicesModel
import mx.arquidiocesis.misiglesias.repository.Repository
import mx.arquidiocesis.misiglesias.viewmodel.DetalleIglesiaViewModel
import mx.arquidiocesis.misiglesias.viewmodel.DetalleIglesiaViewModelFactory


class DetalleIglesiaFragment : Fragment() {
    private val factory by lazy { DetalleIglesiaViewModelFactory(Repository()) }
    private val detalleIglesiaViewModel: DetalleIglesiaViewModel by viewModels { factory }
    private val loadingFragment by lazy { LoadingFragment() }
    private lateinit var coo: CoordinatesModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail_church, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val idIglesia = requireArguments().getInt("idIglesia")
        detalleIglesiaViewModel.obtenerDetalle(idIglesia)

        initObservers()

        showLoader()

        btnEditarIglesia.setOnClickListener {
            val transaction =
                requireActivity().supportFragmentManager.beginTransaction()
            val fragment = EditarIglesiaFragment()
            val bundle = Bundle()
            bundle.putInt("idIglesia", idIglesia)
            fragment.arguments = bundle
            transaction.replace((requireView().parent as ViewGroup).id, fragment)
                .addToBackStack(this@DetalleIglesiaFragment.tag)
                .commit()
        }

        btnLlevame.setOnClickListener {
            val gmmIntentUri =
                Uri.parse("geo:0,0?q="+coo.latitude.toString().replace(",",".")+","+coo.longitude.toString().replace(",","."))
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
            startActivity(mapIntent)
        }
    }

    fun initObservers() {
        detalleIglesiaViewModel.response.observe(viewLifecycleOwner) {
            tvNombreIglesia.text = it.nombre

            coo = it.coordinates

            Glide.with(requireContext())
                .load(Uri.parse(it.image))
                .into(ivChurch)
            tvDescripcionIglesia.text = it.description
            tvDireccionIglesia.text = it.address
            tvHorariosIglesia.text = "Horario: " + it.horary[0].days + " de " + it.horary[0].hours
            tvHorariosOficina.text =
                "Horarios de oficina: " + it.attention[0].days + " de " + it.attention[0].hours
            tvEmail.text = "Email de contacto: " + it.email
            tvPhone.text = "Teléfono: " + it.phone
            tvTransmisionIglesia.text = "Transmisiones en vivo " + it.stream.url
            rvHorariosMisas.apply {
                layoutManager = LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
                adapter = MassAdapter(
                    requireContext(),
                    it.masses as MutableList<MassesModel>, rvHorariosMisas
                ) {

                }
            }
            rvHorariosServicios.apply {
                layoutManager = LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
                adapter = ServiceAdapter(
                    requireContext(),
                    it.services as MutableList<ServicesModel>, rvHorariosServicios
                ) {
                }
            }
            hideLoader()
        }
    }

    private fun showLoader() {
        if (!loadingFragment.isAdded) {
            loadingFragment.show(childFragmentManager, "lOADER")
        }
    }

    private fun hideLoader() {
        if (loadingFragment.isAdded) {
            loadingFragment.dismissAllowingStateLoss()
        }
    }
}