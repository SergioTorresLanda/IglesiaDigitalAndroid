package mx.arquidiocesis.misiglesias.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ParsonModel(var id:Int, var appointment:String,var name:String,var firstSurname:String,var secondSurname:String) : Parcelable