package mx.arquidiocesis.misiglesias.ui

import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.observe
import androidx.recyclerview.widget.LinearLayoutManager
import com.arquidiocesis.misiglesias.R
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.fragment_my_churches.*
import mx.arquidiocesis.misiglesias.adapters.ChurchAdapter
import mx.arquidiocesis.misiglesias.customviews.LoadingFragment
import mx.arquidiocesis.misiglesias.model.MisIgleciasModel
import mx.arquidiocesis.misiglesias.repository.Repository
import mx.arquidiocesis.misiglesias.viewmodel.MisIgleciasViewModel
import mx.arquidiocesis.misiglesias.viewmodel.MisIgleciasViewModelFactory

class MisIglesiasFragment : Fragment() {

    private val factory by lazy { MisIgleciasViewModelFactory(Repository()) }
    private val misIgleciasViewModel: MisIgleciasViewModel by viewModels { factory }
    private val loadingFragment by lazy { LoadingFragment() }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout.fragment_my_churches, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initObservers()
        misIgleciasViewModel.oracionesList(1)
        showLoader()
        ivAddIglecia.setOnClickListener {
            val transaction =
                requireActivity().supportFragmentManager.beginTransaction()
            val fragment = EditarIglesiaFragment()

            transaction.replace((requireView().parent as ViewGroup).id, fragment).addToBackStack(tag)
                .commit()
        }

    }

    fun initObservers() {
        misIgleciasViewModel.response.observe(viewLifecycleOwner) { misIgleciasModel ->
            tvIglesia.text=misIgleciasModel.assigned.tag
            Glide.with(requireContext())
                .load(Uri.parse(misIgleciasModel.assigned.image))
                .into(ivIglesia)
            cvAsignado.setOnClickListener {
                val transaction =
                    requireActivity().supportFragmentManager.beginTransaction()
                val fragment = DetalleIglesiaFragment()
                val bundle = Bundle()
                bundle.putInt("idIglesia", misIgleciasModel.assigned.id)
                fragment.arguments = bundle
                transaction.replace((requireView().parent as ViewGroup).id, fragment).addToBackStack(this@MisIglesiasFragment.tag)
                    .commit()
            }
            rvListaIglesias.apply {
                layoutManager =  LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
                adapter = ChurchAdapter(requireContext(),misIgleciasModel.churches){
                        item ->
                    val transaction =
                        requireActivity().supportFragmentManager.beginTransaction()
                    val fragment = DetalleIglesiaFragment()
                    val bundle = Bundle()
                    bundle.putInt("idIglesia", item.id)
                    fragment.arguments = bundle
                    transaction.replace((requireView().parent as ViewGroup).id, fragment).addToBackStack(this@MisIglesiasFragment.tag)
                        .commit()
                }

            }
            hideLoader()
        }
    }
    private fun showLoader() {
        if (!loadingFragment.isAdded) {
            loadingFragment.show(childFragmentManager, "lOADER")
        }
    }

    private fun hideLoader() {
        if (loadingFragment.isAdded) {
            loadingFragment.dismissAllowingStateLoss()
        }
    }

}