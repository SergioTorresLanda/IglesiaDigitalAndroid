package mx.arquidiocesis.misiglesias.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ServicesModel(var id: Int, var icon: String,var name: String, var day: String,var hours: String) : Parcelable//SERVICIOS