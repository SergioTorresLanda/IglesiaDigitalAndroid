package mx.arquidiocesis.misiglesias.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MassesModel(var id:Int,var icon:String,var name:String,var days:String,var hours:String) : Parcelable//MISAS