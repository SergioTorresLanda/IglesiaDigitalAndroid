package mx.arquidiocesis.misiglesias.repository

import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import mx.arquidiocesis.misiglesias.model.*
import mx.arquidiocesis.misiglesias.retrofit.RetrofitClient
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Repository {

    val iglesiasResponse = MutableLiveData<MisIgleciasModel>()
    val detalleResponse = MutableLiveData<DetalleIglesiasModel>()
    val iglesiasPutResponse = MutableLiveData<RespuestaModel>()
    val catalogoMassesResponse = MutableLiveData<List<MassesModel>>()
    val catalogoServiciosResponse = MutableLiveData<List<ServicesModel>>()
    val errorResponse = MutableLiveData<String>()

    fun iglesiasList(id: Int) {
        val call = RetrofitClient.apiInterface.getListadoIglesias(id)
        call.enqueue(object : Callback<MisIgleciasModel> {
            override fun onFailure(call: Call<MisIgleciasModel>, t: Throwable) {
                errorResponse.value = "Error Appointments : $t"
            }

            override fun onResponse(
                call: Call<MisIgleciasModel>,
                response: Response<MisIgleciasModel>
            ) {
                val data = response.body()
                iglesiasResponse.value = data
            }
        })
    }

    fun obtenerDetalle(id: Int) {
        val call = RetrofitClient.apiInterface.getDetalleIglesias(id)
        call.enqueue(object : Callback<DetalleIglesiasModel> {
            override fun onFailure(call: Call<DetalleIglesiasModel>, t: Throwable) {
                errorResponse.value = "Error Appointments : $t"
            }

            override fun onResponse(
                call: Call<DetalleIglesiasModel>,
                response: Response<DetalleIglesiasModel>
            ) {
                val data = response.body()
                detalleResponse.value = data
            }
        })
    }

    fun putIglesias(id: Int, editarIglesiasModel: EditarIglesiasModel) {
        val gson = Gson()
        val json = JSONObject(gson.toJson(editarIglesiasModel))
        val call = RetrofitClient.apiInterface.addIglesiasRegister(id, json)
        call.enqueue(object : Callback<RespuestaModel> {
            override fun onFailure(call: Call<RespuestaModel>, t: Throwable) {
                errorResponse.value = "Error Appointments : $t"

            }

            override fun onResponse(
                call: Call<RespuestaModel>,
                response: Response<RespuestaModel>
            ) {
                val data = response.body()
                iglesiasPutResponse.value = data
            }
        })
    }

    fun getCatalogMisas() {
        val call = RetrofitClient.apiInterface.getCatalogMisas()
        call.enqueue(object : Callback<List<MassesModel>> {
            override fun onFailure(call: Call<List<MassesModel>>, t: Throwable) {
                errorResponse.value = "Error Appointments : $t"
            }

            override fun onResponse(
                call: Call<List<MassesModel>>,
                response: Response<List<MassesModel>>
            ) {
                val data = response.body()
                catalogoMassesResponse.value = data
            }
        })
    }

    fun getCatalogServicios() {
        val call = RetrofitClient.apiInterface.getCatalogServicios()
        call.enqueue(object : Callback<List<ServicesModel>> {
            override fun onFailure(call: Call<List<ServicesModel>>, t: Throwable) {
                errorResponse.value = "Error Appointments : $t"
            }

            override fun onResponse(
                call: Call<List<ServicesModel>>,
                response: Response<List<ServicesModel>>
            ) {
                val data = response.body()
                catalogoServiciosResponse.value = data
            }
        })
    }
}