package mx.arquidiocesis.misiglesias.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class AssignedModel(var id: Int,var tag:String,var image:String) : Parcelable