package mx.arquidiocesis.misiglesias.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ActivitiesEditModel(var type: Int, var days: String,var hours:String) : Parcelable//ACTIVIDADES