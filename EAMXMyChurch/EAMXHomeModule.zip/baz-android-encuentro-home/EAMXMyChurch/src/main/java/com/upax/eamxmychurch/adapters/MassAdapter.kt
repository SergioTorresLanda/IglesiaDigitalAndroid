package mx.arquidiocesis.misiglesias.adapters

import android.app.AlertDialog
import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.upax.eamxmychurch.databinding.ItemMassBinding
import mx.arquidiocesis.misiglesias.model.MassesModel
import mx.arquidiocesis.misiglesias.model.ServicesModel
import mx.arquidiocesis.misiglesias.utils.PublicFunctions

class MassAdapter(
    val context: Context,
    var messes: MutableList<MassesModel>,
    var recyclerView: RecyclerView,
    val listener: (MassesModel) -> Unit
) :
    RecyclerView.Adapter<MassAdapter.MassesViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MassesViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemMassBinding.inflate(inflater, parent, false)
        return MassesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MassesViewHolder, position: Int) =
        holder.bind(context, listener, messes[position], this)

    override fun getItemCount(): Int = messes.size
    fun updateReceiptsList(item: MassesModel) {
        messes.add(item)
        recyclerView.post(Runnable { notifyDataSetChanged() })
    }

    fun updateReceiptsList(item: MutableList<MassesModel>) {
        messes = item

        recyclerView.post(Runnable { notifyDataSetChanged() })
    }

    fun deleteReceiptsList(item: MassesModel) {
        messes.remove(item)

        recyclerView.post(Runnable { notifyDataSetChanged() })
    }

    class MassesViewHolder(val binding: ItemMassBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
            }
        }

        fun bind(
            context: Context,
            listener: (MassesModel) -> Unit, masse: MassesModel,
            adapter: MassAdapter
        ) {
            binding.tvMass.text = masse.name
            if (masse.days !== null) {
                binding.tvDia.text = masse.days
            }
            if (masse.hours!== null) {
                binding.tvHorario.text = masse.hours
            }

            if (masse.icon != null) {
                Glide.with(context)
                    .load(Uri.parse(masse.icon)).apply(RequestOptions().override(40, 50))
                    .into(binding.ivIcon)
            }

            binding.imClose.setOnClickListener {
                adapter.deleteReceiptsList(masse)
            }
            binding.root.setOnClickListener {
                listener(masse)
            }

            binding.ivEditDays.setOnClickListener {
                val days =
                    mutableListOf("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo")
                PublicFunctions().selectDayRange(context, binding.tvDia,days,"")
            }


            binding.ivEditHours.setOnClickListener {
                PublicFunctions().selectFirstHour(context, binding.tvHorario,"")
            }
        }




    }
}